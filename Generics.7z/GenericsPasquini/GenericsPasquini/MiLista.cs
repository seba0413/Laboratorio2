﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsPasquini
{
    public class MiLista <T> : IEnumerable <T>
    {
        private T [] lista;

        public MiLista()
        {
            this.lista = new T[0];
        }

        public T this [int t]
        {
            get
            {
                return lista[t];
            }
        }


        public int DatoDeMiLista
        {
            get
            {
                return 5;
            }

            set
            {
                if (value != 5)
                    throw new Exception();
            }
        }

        public int Count
        {
            get
            {
                return this.lista.Length;
            }
        }

        public void Add(T item)
        {
            Array.Resize(ref lista, lista.Length + 1);
            this.lista[lista.Length - 1] = item;
        }

        public void Remove(T item)
        {
            for(int i = 0; i < this.lista.Length; i++)
            {
                if(this.lista[i].Equals(item))
                {
                    for(int j = i; j < this.Count; j++)
                    {
                        this.lista[j] = this.lista[j + 1];
                    }
                    break;
                }
            }
            Array.Resize(ref lista, this.Count - 1);
        }

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            foreach(T item in this.lista)
            {
                yield return item; 
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            for(int index = 0; index < this.lista.Length; index++)
            {
                yield return this.lista[index];
            }
        }
    }
}
 
﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GenericsPasquini;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            MiLista<int> a = new MiLista<int>();

            try
            {
                a.DatoDeMiLista = 3;
            }
            catch (Exception e)
            {
                //Assert.IsTrue(e.GetType() == typeof(Exception));
                Assert.IsInstanceOfType(e, typeof(Exception));
            }
            //Assert.Fail();        
        }

        [TestMethod]
        public void pruebaAdd()
        {
            MiLista<int> lista = new MiLista<int>();
            lista.Add(4);
            lista.Add(40);

            Assert.IsTrue(lista.Count == 2);

            int i = 0;
            foreach (int item in lista)
            {
                Assert.AreEqual(item, lista[i]);
                i++;
            }

            MiLista<string> listad = new MiLista<string>();
            listad.Add("4");
            listad.Add("40");

            Assert.IsTrue(listad.Count == 2);
        }        
    }
}
